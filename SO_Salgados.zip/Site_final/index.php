<?php 
	

		try{require 'init.php';
			if(isset($_POST['enviar']) && !empty($_POST['comentario'])){
				echo "<script>alert('Pedeido enviado com sucesso!');</script>";

                $nome = $_POST['nome'];
                $sobrenome = $_POST['sobrenome'];
                $data_nascimento = $_POST['birthdate'];
                $email = $_POST['email'];
                $cpf = $_POST['cpf'];
                $sexo = $_POST['sexo'];
                $telefone = $_POST['telefone'];
                $comentario = $_POST['comentario'];

				$sql = "insert INTO `contato`(`first_name`, `last_name`, `birthdate`, `email`, `cpf`, `gender`, `telefone`, `comentario`) VALUES (:nome,:sobrenome,:data_nascimento,:email,:cpf,:sexo,:telefone,:comentario);";

				$stmt = $PDO->prepare($sql);
                $stmt->bindValue(':nome',$nome);
                $stmt->bindValue(':sobrenome',$sobrenome);
                $stmt->bindValue(':data_nascimento',$data_nascimento);
                $stmt->bindValue(':email',$email);
                $stmt->bindValue(':cpf',$cpf);
                $stmt->bindValue(':sexo',$sexo);
                $stmt->bindValue(':telefone',$telefone);
                $stmt->bindValue(':comentario',$comentario);
				$stmt->execute();
			}	
			
			 
		}catch(PDOexception $e){
			echo 'Erro: ' . $e->getCode() . 'Mensagem: ' . $e->getMessage();
		}		

		

 ?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Só Salgados</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="node_modules/bootstrap/compiled/bootstrap.css" />
    <link rel="stylesheet" href="css/eventos.css">
    <link rel="stylesheet" href="css/contatos.css">
    <!-- CSS Desenvolvedor -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>
    <header>
        <!-- Navbar Mobile -->
        <nav class="navbar navbar-expand-lg nav-mobile fixed-top">
            <div class="container">
                <a class="navbar-brand" href=""><img src="img/logo1.png" width="50"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
                    <i><img src="img\icones\menu.png" class="btn-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarSite">
                    <ul class="navbar-nav">
                        <hr id="linha">
                        <li class="nav-item">
                            <a class="nav-link btn-cor" href="#">Quem Somos?</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-cor" href="#produtos">Produtos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-cor" href="#">Receitas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-cor" href="#Eventos">Eventos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-cor" href="#contatos">Contatos</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Fim Navbar Mobile -->

        <!-- Navbar Web -->
        <div class="nav-web">
            <div class="logo">
                <a class="justify-content-center text-center fixed-top logo" href=""><img src="img/logo.png" class="logo"></a>
            </div>
            <div>
                <nav class="navbar navbar-expand-lg nav-cor justify-content-center text-center">
                    <div class="" id="navbarSite">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item mr-5">
                                <a class="nav-link btn-home " href="#">Quem Somos?</a>
                            </li>
                            <li class="nav-item mr-5">
                                <a class="nav-link btn-home " href="#produtos">Produtos</a>
                            </li>
                            <li class="nav-item mr-5">
                                <a class="nav-link btn-home " href="#">Receitas</a>
                            </li>
                            <li class="nav-item mr-5">
                                <a class="nav-link btn-home " href="#Eventos">Eventos</a>
                            </li>
                            <li class="nav-item mr-5">
                                <a class="nav-link btn-home " href="#contatos">Contatos</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Fim da Navbar Web -->
    </header>

    <!-- Home -->
    <section id="">
        <div id="carouselSite" class="carousel slide" data-ride="carousel">
            <!-- Indicadores do Slide -->
            <ol class="carousel-indicators">
                <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
                <li data-target="#carouselSite" data-slide-to="1"></li>
                <li data-target="#carouselSite" data-slide-to="2"></li>
            </ol>
            <!-- Imagens do Slide -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img\home\slide01.jpg" class="img-fluid d-block img-slide w-100">
                </div>
                <div class="carousel-item">
                    <img src="img\home\slide02.jpg" class="img-fluid d-block img-slide w-100">
                </div>
                <div class="carousel-item">
                    <img src="img\home\slide03.jpg" class="img-fluid d-block img-slide w-100">
                </div>
            </div>
            <!-- Botões do slide -->
            <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
                <i><img src="img\icones\left-chevron.png" class="seta"></i>
                <span class="sr-only">Anterior</span>
            </a>
            <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
                <i><img src="img\icones\right-chevron.png" class="seta"></i>
                <span class="sr-only">Próximo</span>
            </a>
        </div>
    </section>

    <!-- Produtos -->
    <section id="produtos">
        <div class="container">
            <div class="row">
                <h1 id="prod-titulo" class="m-3">Produtos</h1>
            </div>
            <div class="row">
                <div class="col">
                    <img src="img/produto/produto01.jpg" class="img-produtos mt-3">
                    <div class="texto-produtos">
                        <h5 class="text-center">Quindin</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
                <div class="col">
                    <img src="img/produto/produto02.jpg" class="img-produtos mt-3">
                    <div class="texto-produtos">
                        <h5 class="text-center">Risole</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
                <div class="col">
                    <img src="img/produto/produto03.jpg" class="img-produtos mt-3">
                    <div class="texto-produtos">
                        <h5 class="text-center">Queijadiinha</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
                <div class="col">
                    <img src="img/produto/produto04.jpg" class="img-produtos mt-3">
                    <div class="texto-produtos">
                        <h5 class="text-center">Coxinha</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Eventos -->
    <div id="Eventos">

        <!-- LINHA 1 (IMG NA ESQUERDA) -->
        <section class="features16 Img_de_eventos_Esquerda" id="features16-5">
            <div class="container">
                <div class="row main align-items-center">
                    <div class="col-md-6 image-element ">
                        <div class="img-wrap">
                            <img src="img\Eventos\buffet01.jpeg" alt="" title="">
                        </div>
                    </div>
                    <div class="col-md-6 text-element text-center"> <!-- TEXTOS -->
                        <div class="text-content">
                            <div class="mbr-section-text">
                                <h2>Lorem</h2>
                                <p class="mbr-text pt-3 mbr-light mbr-fonts-style align-left mbr-white display-5">
                                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aperiam quae ipsum quas nulla? Excepturi optio, voluptatibus nostrum fuga dolorem corrupti. Porro distinctio quod non sit! Obcaecati ullam nostrum numquam laboriosam!
                                </p>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>          
        </section>
            <!-- FIM LINHA 1 (IMG NA ESQUERDA) -->
            
        <!-- INICIO LINHA 2 (IMG NA DIREITA) -->
        <section class="features17 Img_de_eventos_Direita" id="features17-6">
            <div class="container">
                <div class="row main align-items-center">
                    <div class="col-md-6 image-element">
                        <div class="img-wrap">
                            <img src="img\Eventos\buffet02.jpeg" alt="" title="">
                        </div>
                    </div>
                    <div class="col-md-6 text-element text-center"> <!-- TEXTOS -->
                        <div class="text-content">
                            <div class="mbr-section-text">
                                <h2>Lorem</h2>
                                <p class="mbr-text pt-3 mbr-light mbr-fonts-style align-left mbr-white display-5">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae quaerat modi quae consequatur nobis molestiae, distinctio tempora perferendis. Quae numquam reiciendis ullam cupiditate unde soluta veniam nemo! Iste, vitae exercitationem!    
                                </p>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>          
        </section>
        <!-- FIM LINHA 2 (IMG NA DIREITA) -->
        
        <!-- LINHA 3 (IMG NA ESQUERDA) -->
        <section class="features16 Img_de_eventos_Esquerda" id="features16-5">
            <div class="container">
                <div class="row main align-items-center">
                    <div class="col-md-6 image-element ">
                        <div class="img-wrap">
                            <img src="img\Eventos\buffet03.jpeg" alt="" title="">
                        </div>
                    </div>
                    <div class="col-md-6 text-element text-center"> <!-- TEXTOS -->
                        <div class="text-content">
                            <div class="mbr-section-text">
                                <h2>Lorem</h2>
                                <p class="mbr-text pt-3 mbr-light mbr-fonts-style align-left mbr-white display-5 ">
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Suscipit amet autem consequuntur esse ratione. Ullam doloribus rem quas sunt delectus enim consequatur repudiandae, deleniti blanditiis, in nam, provident ea aliquid.    
                                </p>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>          
        </section>
        <!-- FIM LINHA 3 (IMG NA ESQUERDA) -->
    </div>
    <!-- FIM EVENTOS -->
  
    <!-- Começa a parte de contatos -->

    <section id="contatos" class="padd-section wow fadeInUp">
        <!-- FORMULARIO -->
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-12">
                    <div class="form">
                        <form action="" method="post" role="form" class="contactForm">
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label for="inputName">Nome *</label>
                                    <input type="text" required class="form-control" name="nome" id="inputName" placeholder="Nome">
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="inputLastName">Sobrenome *</label>
                                    <input type="text" required class="form-control" id="inputName" placeholder="Sobrenome">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="inputDate">Nascimento *</label>
                                    <input type="date" required class="form-control" name="birthdate" id="inputDate" placeholder="Data de Nascimento">
                                </div>
                            
                                <div class="form-group col-md-6">
                                    <label for="inputEmail4">Email *</label>
                                <input type="email" required class="form-control" id="inputEmail" placeholder="Email">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="inputCPF">CPF/CNPJ *</label>
                                    <input type="text" required class="form-control mascara-cpfcnpj">
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="inputGender">Sexo *</label>
                                    <select id="inputGender" class="form-control" placeholder="Sexo">
                                        <option selected value="nenhum">Indeterminado</option>
                                        <option value="masculino">Masculino</option>
                                        <option value="feminino">Feminino</option>
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="inputTelephone">Telefone *</label>
                                    <input type="text" class="form-control" required id="inputTelephone">
                                </div>

                                <div class="form-group col-md-12">
                                    <label for="inputComment">Comentario *</label>
                                    <textarea type="text" class="form-control" required name="comentario" id="subject" placeholder="Escreva aqui..."></textarea>
                                    <div class="validation"></div>
                                </div>

                                <div class="form-group col-md-12">
                                    <input type="submit" name="Enviar" class="btn btn-primary col-md-12">
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        
            <div class="col-lg-4 col-md-8">
                <div class="info contatos text-center">
                    <div>
                        <i class="fa fa-phone"></i>
                        <p>Telefone: (71) 3333-3333</p><br>
                    </div>

                    <div>
                        <i class="fa fa-map-marker"></i>
                        <p><img src="img\Contatos\Maps.png" width="30" alt="">Caminho das Árvores, Salvador - BA 40301-155</p>
                    </div>
                </div>

                <div class="map-responsive">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15552.07172043717!2d-38.4606134!3d-12.9707044!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7161b1753564b8b%3A0x33b3ce22ea6326f5!2sCaminho+das+%C3%81rvores%2C+Salvador+-+BA%2C+40301-155!5e0!3m2!1spt-BR!2sbr!4v1540160323859" frameborder="0" ></iframe>
                </div>

            </div>
        </div> <br><br>
        <a href="login.php">
            <button type="submit" placeholder="" class="btn btn-primary col-md-12">Planilha Excel(Área Restrita)</button>
        </a>
    </section>
    

        <!-- Acaba a parte de contatos -->


    <footer class="text-center">
        Desenvolvido por Caio, Paulo e Jayme. Todos Direitos Reservados
    </footer>

    <!-- JavaScript -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
</div>
</body>
</html>