<?php 
	$login = $_POST['login'];
	$senha = $_POST['senha'];
	$genero = $_POST['sexo'];
	echo $login . ' ' . $senha . ' ' . $genero;
 ?>